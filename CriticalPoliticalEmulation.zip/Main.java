import javax.swing.*;
import test.*;
public class Main{
	static JFrame frame;
	static JButton button;
	public static void main(String[] args){
		frame = new JFrame("test");
		button = new JButton("click me");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().add(button);
		frame.setSize(300,300);
		frame.setVisible(true);
		Gui gui = new Gui();
	}
}