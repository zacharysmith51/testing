package test;

import java.awt.event.*;

public class Gui{
	class testListener implements ActionListener {
    	public void actionPerformed(ActionEvent e) {
			System.out.println("test");
    	}
	}
	class testsubclass{
		void test(){
			System.out.println("hi");
		}
		class hi{
			void test_sub(){
				System.out.println("hi");
			}
			class test{
				void test_sub(){
					System.out.println("hi");
				}
			}
		}
	}
	class testsubclass1{
		void test(){
			System.out.println("hi");
		}
		class hi{
			void test_sub(){
				System.out.println("hi");
			}
			class test{
				void test_sub(){
					System.out.println("hi");
				}
			}
		}
	}
	class testsubclass2{
		void test(){
			System.out.println("hi");
		}
		class hi{
			void test_sub(){
				System.out.println("hi");
			}
			class test{
				void test_sub(){
					System.out.println("hi");
				}
			}
		}
	}
	class testsubclass3{
		void test(){
			System.out.println("hi");
		}
		class hi{
			void test_sub(){
				System.out.println("hi");
			}
			class test{
				void test_sub(){
					System.out.println("hi");
				}
			}
		}
	}
	class testsubclass4{
		void test(){
			System.out.println("hi");
		}
		class hi{
			void test_sub(){
				System.out.println("hi");
			}
			class test{
				void test_sub(){
					System.out.println("hi");
				}
			}
		}
	}
	class testsubclass5{
		void test(){
			System.out.println("hi");
		}
		class hi{
			void test_sub(){
				System.out.println("hi");
			}
			class test{
				void test_sub(){
					System.out.println("hi");
				}
				class testsubclasss{
					void test(){
						System.out.println("hi");
					}
					class hihi{
						void test_sub(){
							System.out.println("hi");
						}
						class testing{
							void test_sub(){
								System.out.println("hi");
							}
						}
					}
				}
			}
		}
	}
	class testsubclass6{
		void test(){
			System.out.println("hi");
		}
		class hi{
			void test_sub(){
				System.out.println("hi");
			}
			class test{
				void test_sub(){
					System.out.println("hi");
				}
				class testsubclasss{
					void test(){
						System.out.println("hi");
					}
					class hihi{
						void test_sub(){
							System.out.println("hi");
						}
						class testing{
							void test_sub(){
								System.out.println("hi");
							}
						}
					}
				}
			}
		}
	}
	class testsubclass7{
		void test(){
			System.out.println("hi");
		}
		class hi{
			void test_sub(){
				System.out.println("hi");
			}
			class test{
				void test_sub(){
					System.out.println("hi");
				}
				class testsubclasss{
					void test(){
						System.out.println("hi");
					}
					class hihi{
						void test_sub(){
							System.out.println("hi");
						}
						class testing{
							void test_sub(){
								System.out.println("hi");
							}
						}
					}
				}
			}
		}
	}
	class testsubclass8{
		void test(){
			System.out.println("hi");
		}
		class hi{
			void test_sub(){
				System.out.println("hi");
			}
			class test{
				void test_sub(){
					System.out.println("hi");
				}
				class testsubclasss{
					void test(){
						System.out.println("hi");
					}
					class hihi{
						void test_sub(){
							System.out.println("hi");
						}
						class testing{
							void test_sub(){
								System.out.println("hi");
							}
						}
					}
				}
			}
		}
	}
	class testsubclass9{
		void test(){
			System.out.println("hi");
		}
		class hi{
			void test_sub(){
				System.out.println("hi");
			}
			class test{
				void test_sub(){
					System.out.println("hi");
				}
				class testsubclasss{
					void test(){
						System.out.println("hi");
					}
					class hihi{
						void test_sub(){
							System.out.println("hi");
						}
						class testing{
							void test_sub(){
								System.out.println("hi");
							}
							class testsubclass9hi{
								void test(){
									System.out.println("hi");
								}
								class hi1{
									void test_sub(){
										System.out.println("hi");
									}
									class test1{
										void test_sub(){
											System.out.println("hi");
										}
										class testsubclassss{
											void test(){
												System.out.println("hi");
											}
											class hihihi{
												void test_sub(){
													System.out.println("hi");
												}
												class testinghi{
													void test_sub(){
														System.out.println("hi");
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	class testsubclass10{
		void test(){
			System.out.println("hi");
		}
		class hi{
			void test_sub(){
				System.out.println("hi");
			}
			class test{
				void test_sub(){
					System.out.println("hi");
				}
				class testsubclasss{
					void test(){
						System.out.println("hi");
					}
					class hihi{
						void test_sub(){
							System.out.println("hi");
						}
						class testing{
							void test_sub(){
								System.out.println("hi");
							}
							class testsubclass9hi{
								void test(){
									System.out.println("hi");
								}
								class hi1{
									void test_sub(){
										System.out.println("hi");
									}
									class test1{
										void test_sub(){
											System.out.println("hi");
										}
										class testsubclassss{
											void test(){
												System.out.println("hi");
											}
											class hihihi{
												void test_sub(){
													System.out.println("hi");
												}
												class testinghi{
													void test_sub(){
														System.out.println("hi");
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	class testsubclass11{
		void test(){
			System.out.println("hi");
		}
		class hi{
			void test_sub(){
				System.out.println("hi");
			}
			class test{
				void test_sub(){
					System.out.println("hi");
				}
				class testsubclasss{
					void test(){
						System.out.println("hi");
					}
					class hihi{
						void test_sub(){
							System.out.println("hi");
						}
						class testing{
							void test_sub(){
								System.out.println("hi");
							}
							class testsubclass9hi{
								void test(){
									System.out.println("hi");
								}
								class hi1{
									void test_sub(){
										System.out.println("hi");
									}
									class test1{
										void test_sub(){
											System.out.println("hi");
										}
										class testsubclassss{
											void test(){
												System.out.println("hi");
											}
											class hihihi{
												void test_sub(){
													System.out.println("hi");
												}
												class testinghi{
													void test_sub(){
														System.out.println("hi");
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	class testsubclass12{
		void test(){
			System.out.println("hi");
		}
		class hi{
			void test_sub(){
				System.out.println("hi");
			}
			class test{
				void test_sub(){
					System.out.println("hi");
				}
				class testsubclasss{
					void test(){
						System.out.println("hi");
					}
					class hihi{
						void test_sub(){
							System.out.println("hi");
						}
						class testing{
							void test_sub(){
								System.out.println("hi");
							}
							class testsubclass9hi{
								void test(){
									System.out.println("hi");
								}
								class hi1{
									void test_sub(){
										System.out.println("hi");
									}
									class test1{
										void test_sub(){
											System.out.println("hi");
										}
										class testsubclassss{
											void test(){
												System.out.println("hi");
											}
											class hihihi{
												void test_sub(){
													System.out.println("hi");
												}
												class testinghi{
													void test_sub(){
														System.out.println("hi");
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	class testsubclass13{
		void test(){
			System.out.println("hi");
		}
		class hi{
			void test_sub(){
				System.out.println("hi");
			}
			class test{
				void test_sub(){
					System.out.println("hi");
				}
				class testsubclasss{
					void test(){
						System.out.println("hi");
					}
					class hihi{
						void test_sub(){
							System.out.println("hi");
						}
						class testing{
							void test_sub(){
								System.out.println("hi");
							}
							class testsubclass9hi{
								void test(){
									System.out.println("hi");
								}
								class hi1{
									void test_sub(){
										System.out.println("hi");
									}
									class test1{
										void test_sub(){
											System.out.println("hi");
										}
										class testsubclassss{
											void test(){
												System.out.println("hi");
											}
											class hihihi{
												void test_sub(){
													System.out.println("hi");
												}
												class testinghi{
													void test_sub(){
														System.out.println("hi");
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	class testsubclass14{
		void test(){
			System.out.println("hi");
		}
		class hi{
			void test_sub(){
				System.out.println("hi");
			}
			class test{
				void test_sub(){
					System.out.println("hi");
				}
				class testsubclasss{
					void test(){
						System.out.println("hi");
					}
					class hihi{
						void test_sub(){
							System.out.println("hi");
						}
						class testing{
							void test_sub(){
								System.out.println("hi");
							}
							class testsubclass9hi{
								void test(){
									System.out.println("hi");
								}
								class hi1{
									void test_sub(){
										System.out.println("hi");
									}
									class test1{
										void test_sub(){
											System.out.println("hi");
										}
										class testsubclassss{
											void test(){
												System.out.println("hi");
											}
											class hihihi{
												void test_sub(){
													System.out.println("hi");
												}
												class testinghi{
													void test_sub(){
														System.out.println("hi");
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	class testsubclass15{
		void test(){
			System.out.println("hi");
		}
		class hi{
			void test_sub(){
				System.out.println("hi");
			}
			class test{
				void test_sub(){
					System.out.println("hi");
				}
				class testsubclasss{
					void test(){
						System.out.println("hi");
					}
					class hihi{
						void test_sub(){
							System.out.println("hi");
						}
						class testing{
							void test_sub(){
								System.out.println("hi");
							}
							class testsubclass9hi{
								void test(){
									System.out.println("hi");
								}
								class hi1{
									void test_sub(){
										System.out.println("hi");
									}
									class test1{
										void test_sub(){
											System.out.println("hi");
										}
										class testsubclassss{
											void test(){
												System.out.println("hi");
											}
											class hihihi{
												void test_sub(){
													System.out.println("hi");
												}
												class testinghi{
													void test_sub(){
														System.out.println("hi");
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}